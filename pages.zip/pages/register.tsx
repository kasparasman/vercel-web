import { useState } from "react"
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth"
import { initializeApp } from "firebase/app"

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  // …other public config…
}
const app  = initializeApp(firebaseConfig)
const auth = getAuth(app)

export default function RegisterPage() {
  const [email, setEmail]       = useState("")
  const [password, setPassword] = useState("")

  const handleSubmit = async (e) => {
    e.preventDefault()
    await createUserWithEmailAndPassword(auth, email, password)
    // auto-login or redirect to /login
  }

  return (
    <form onSubmit={handleSubmit}>
      <input type="email"    onChange={e => setEmail(e.target.value)}    />
      <input type="password" onChange={e => setPassword(e.target.value)} />
      <button type="submit">Register</button>
    </form>
  )
}
